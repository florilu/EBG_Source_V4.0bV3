package net.minecraft.src;

import java.awt.image.BufferedImage;

import net.minecraft.client.Minecraft;

import org.lwjgl.opengl.GL11;

public class Strings extends GuiMainMenu 
{

	public void drawScreen(int par1, int par2, float par3)
	{
		String var9 = "Minecraft 1.3.2 fsf";
	}
}
